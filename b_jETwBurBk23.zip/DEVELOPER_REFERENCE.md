# FITPULSE Developer Quick Reference

## Project Commands

```bash
# Start development server
npm start

# Build for production
npm run build

# Run tests
npm test

# Eject configuration (not recommended)
npm run eject
```

## Component Locations

| Component | File | Purpose | Lines |
|-----------|------|---------|-------|
| Hero | `src/components/Hero.js` | Full-screen hero section | 102 |
| About | `src/components/About.js` | Company info & values | 123 |
| Services | `src/components/Services.js` | Service offerings grid | 102 |
| Testimonials | `src/components/Testimonials.js` | Reviews carousel | 114 |
| Pricing | `src/components/Pricing.js` | Membership tiers | 117 |
| Contact | `src/components/Contact.js` | Contact form & info | 208 |
| Header | `src/components/Header.js` | Navigation | 246 |
| Footer | `src/components/Footer.js` | Footer links & info | 144 |

## Key Files for Configuration

| File | Purpose |
|------|---------|
| `tailwind.config.js` | Colors, animations, breakpoints |
| `src/App.css` | Custom animations and gradients |
| `src/index.css` | Global styles and utilities |
| `src/data/mockData.js` | Content and data |
| `public/index.html` | Meta tags and head |

## Color Palette Quick Reference

```javascript
// Primary Colors (in Tailwind)
primary-600:  #7c3aed  (Purple - Main brand)
accent-600:   #e91e63  (Magenta - Highlights)
energy-600:   #06b6d4  (Cyan - Accents)

// Backgrounds
bg-slate-950: #0f172a  (Dark navy)
bg-slate-900: #1a2f4f  (Secondary)

// Text
text-white:     #ffffff    (Primary text)
text-gray-400:  #9ca3af    (Secondary text)
text-gray-500:  #6b7280    (Tertiary text)
```

## Common Styling Patterns

### Buttons
```jsx
// Primary Button
<button className="px-6 py-3 bg-gradient-to-r from-primary-600 to-accent-600 text-white rounded-lg font-bold hover:shadow-lg hover:shadow-accent-500/50 transition-all">
  Click Me
</button>

// Secondary Button
<button className="px-6 py-3 border-2 border-primary-500/50 text-white rounded-lg font-bold hover:bg-primary-500/10 transition-all">
  Secondary
</button>
```

### Cards
```jsx
// Glass Card
<div className="glass-card p-6 border border-primary-500/20 rounded-2xl backdrop-blur-xl hover:border-accent-500/50 transition-all duration-300">
  Content here
</div>
```

### Gradients
```jsx
// Gradient Text
<h1 className="gradient-text text-5xl font-black">
  Gradient Text
</h1>

// Gradient Background
<div className="bg-gradient-to-r from-primary-600 via-accent-600 to-energy-600">
  Content
</div>
```

### Animations
```css
/* Fade In */
@keyframes fadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}

/* Slide Up */
@keyframes slideUp {
  from { 
    opacity: 0;
    transform: translateY(30px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

/* Glow Pulse */
@keyframes glowPulse {
  0%, 100% { box-shadow: 0 0 20px rgba(233, 30, 99, 0.4); }
  50% { box-shadow: 0 0 40px rgba(233, 30, 99, 0.6); }
}
```

## Mock Data Structure

```javascript
// From src/data/mockData.js

export const stats = [
  { value: 5000, label: 'Active Members' },
  { value: 50, label: 'Expert Trainers' },
  { value: 100, label: 'Classes/Month' }
]

export const services = [
  {
    id: 1,
    title: 'Personal Training',
    description: '...',
    icon: 'FaDumbbell'
  },
  // ... more services
]

export const testimonials = [
  {
    id: 1,
    name: 'John Doe',
    rating: 5,
    text: '...',
    initials: 'JD'
  },
  // ... more testimonials
]

export const pricingPlans = [
  {
    id: 1,
    name: 'Basic',
    price: 29,
    features: [...]
  },
  // ... more plans
]
```

## Responsive Breakpoints

```css
xs: 320px   (mobile phones)
sm: 640px   (tablets)
md: 768px   (small laptops)
lg: 1024px  (laptops)
xl: 1280px  (desktops)
2xl: 1536px (large screens)
```

## Tailwind Utility Classes

### Spacing
```
p-4   = padding 16px
m-4   = margin 16px
gap-4 = gap 16px
px-6  = padding left/right 24px
py-3  = padding top/bottom 12px
```

### Flexbox
```
flex              = display: flex
flex-col          = flex-direction: column
items-center      = align-items: center
justify-between   = justify-content: space-between
gap-4             = gap: 16px
```

### Grid
```
grid              = display: grid
grid-cols-2       = 2-column grid
grid-cols-3       = 3-column grid
gap-6             = gap: 24px
md:grid-cols-3    = 3 columns on tablet+
```

### Typography
```
text-xl        = font-size: 1.25rem
font-bold      = font-weight: 700
font-black     = font-weight: 900
text-center    = text-align: center
text-white     = color: white
```

### Transforms
```
hover:scale-105    = scale 105% on hover
hover:translate-y  = translateY on hover
transition-all     = animate all changes
duration-300       = animation 300ms
```

## Common Props & Attributes

### React Component Props
```jsx
// Using key for lists
{items.map((item) => (
  <div key={item.id}>{item.name}</div>
))}

// Conditional rendering
{isVisible && <Component />}

// Event handlers
onClick={() => handleClick(id)}
onSubmit={(e) => handleSubmit(e)}
onChange={(e) => setValue(e.target.value)}
```

### DOM Attributes
```jsx
// IDs for scroll targets
id="hero"
id="services"
id="pricing"

// ARIA labels for accessibility
aria-label="Close menu"
aria-hidden="true"
role="button"

// Form attributes
type="email"
required
placeholder="Your email"
disabled={isLoading}
```

## Section IDs for Navigation

These IDs are used for smooth scrolling:

```
#hero           → Hero section
#about          → About section
#services       → Services section
#testimonials   → Testimonials section
#pricing        → Pricing section
#contact        → Contact section
```

Usage in navigation:
```jsx
<a href="#services" onClick={(e) => {
  e.preventDefault();
  document.getElementById('services').scrollIntoView({ behavior: 'smooth' });
}}>
  Services
</a>
```

## Form Handling

### Contact Form Structure
```jsx
const [formData, setFormData] = useState({
  name: '',
  email: '',
  message: ''
});

const handleChange = (e) => {
  const { name, value } = e.target;
  setFormData(prev => ({
    ...prev,
    [name]: value
  }));
};

const handleSubmit = (e) => {
  e.preventDefault();
  // Validation and submission
  console.log('Form submitted:', formData);
};
```

## Animation Utilities

### Trigger Animations on Scroll
```javascript
const useScrollAnimation = (ref) => {
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('animate-in');
        }
      },
      { threshold: 0.3 }
    );
    
    if (ref.current) {
      observer.observe(ref.current);
    }
    
    return () => observer.disconnect();
  }, []);
};
```

## Image Optimization

### Using Next.js Image (if needed)
```jsx
import Image from 'next/image';

<Image
  src="/images/hero.jpg"
  alt="Hero image"
  width={800}
  height={600}
  priority
/>
```

### Standard img Tag
```jsx
<img 
  src="/images/hero.jpg" 
  alt="Hero image"
  className="w-full h-auto object-cover"
/>
```

## Debugging Tips

### Console Logging
```javascript
console.log('[FITPULSE] Value:', value);
console.error('[FITPULSE] Error:', error.message);
console.warn('[FITPULSE] Warning:', warning);
```

### React DevTools
- Install React Developer Tools browser extension
- Inspect component props and state
- Trace component renders

### Tailwind Configuration
- Check `tailwind.config.js` for custom values
- Use DevTools to inspect computed styles
- Verify color variables are defined

### Animation Debugging
- Use DevTools Performance tab
- Check CSS animations in inspector
- Look for 60fps performance

## Common Issues & Solutions

### Colors Not Showing
**Problem**: Classes like `primary-600` don't apply color
**Solution**: Check `tailwind.config.js` has the color defined

### Animations Not Running
**Problem**: Elements don't animate on scroll
**Solution**: Ensure `fade-in-section` class is applied and CSS is loaded

### Layout Breaking
**Problem**: Grid/flex layouts look wrong on mobile
**Solution**: Check responsive classes (md:, lg:) are correct

### Form Not Submitting
**Problem**: Form submission doesn't work
**Solution**: Add event listener and handle form data properly

## Git Workflow

```bash
# Check status
git status

# View changes
git diff

# Stage changes
git add .

# Commit
git commit -m "feat: add new component"

# Push
git push origin main
```

## Performance Tips

1. **Use transform/opacity for animations** - GPU accelerated
2. **Lazy load images** - Intersection Observer
3. **Code split components** - Dynamic imports
4. **Minimize bundle size** - Tree shaking
5. **Cache static assets** - Service workers

## Accessibility Checklist

- [ ] All images have alt text
- [ ] Color contrast > 4.5:1
- [ ] Keyboard navigation works
- [ ] Focus states visible
- [ ] Screen reader compatible
- [ ] Form labels associated with inputs
- [ ] Skip to main content link

## Resources

- **Tailwind CSS**: https://tailwindcss.com
- **React Docs**: https://react.dev
- **MDN Web Docs**: https://developer.mozilla.org
- **Can I Use**: https://caniuse.com

---

**Last Updated**: 2026-04-14  
**Status**: ✅ Complete
