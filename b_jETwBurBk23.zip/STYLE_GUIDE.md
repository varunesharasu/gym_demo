# FITPULSE Visual Style Guide

## Color System

### Primary Brand Colors

#### Purple - Primary Brand Color
```
RGB: rgb(124, 58, 237)
HEX: #7c3aed
HSL: hsl(259, 90%, 55%)
Usage: Primary CTAs, Active states, Main accents
```

#### Magenta - Secondary Accent
```
RGB: rgb(233, 30, 99)
HEX: #e91e63
HSL: hsl(344, 83%, 52%)
Usage: Secondary CTAs, Highlights, Focus states
```

#### Cyan - Tertiary Accent
```
RGB: rgb(6, 182, 212)
HEX: #06b6d4
HSL: hsl(188, 94%, 43%)
Usage: Energy elements, Links, Tertiary accents
```

### Background Colors

#### Primary Background
```
HEX: #0f172a
Usage: Main page background
Contrast: 96% darker than white
```

#### Secondary Background
```
HEX: #1a2f4f
Usage: Section backgrounds, Cards
Contrast: 94% darker than white
```

### Text Colors

#### Primary Text (White)
```
HEX: #ffffff
RGB: rgb(255, 255, 255)
Contrast Ratio: 21:1 (AAA)
Usage: Headlines, important text
```

#### Secondary Text (Light Gray)
```
HEX: #e5e7eb
RGB: rgb(229, 231, 235)
Contrast Ratio: 11:1 (AAA)
Usage: Body text, descriptions
```

#### Tertiary Text (Medium Gray)
```
HEX: #9ca3af
RGB: rgb(156, 163, 175)
Contrast Ratio: 5.5:1 (AA)
Usage: Muted text, helper text
```

### Gradient Combinations

#### Primary-to-Accent Gradient
```css
background: linear-gradient(135deg, #7c3aed 0%, #e91e63 100%);
```
Usage: CTAs, hero section overlays

#### Primary-to-Cyan Gradient
```css
background: linear-gradient(180deg, #7c3aed 0%, #06b6d4 100%);
```
Usage: Text gradients, accent elements

#### Accent-to-Cyan Gradient
```css
background: linear-gradient(135deg, #e91e63 0%, #06b6d4 100%);
```
Usage: Special highlights, gradients

#### All Three Colors
```css
background: linear-gradient(135deg, #7c3aed 0%, #e91e63 50%, #06b6d4 100%);
```
Usage: Hero sections, featured elements

## Typography

### Font Family
- **Primary Font**: Inter
- **Fallback**: system-ui, -apple-system, sans-serif
- **Weight Range**: 300-900

### Type Scale

#### Heading 1 (5xl)
```
Size: 3rem (48px)
Weight: 900 (Black)
Line-height: 1.2
Letter-spacing: -0.02em
Usage: Page titles, main hero heading
```

#### Heading 2 (4xl)
```
Size: 2.25rem (36px)
Weight: 800 (Extra Bold)
Line-height: 1.3
Letter-spacing: -0.01em
Usage: Section titles
```

#### Heading 3 (3xl)
```
Size: 1.875rem (30px)
Weight: 700 (Bold)
Line-height: 1.4
Letter-spacing: 0
Usage: Card titles, subsections
```

#### Heading 4 (2xl)
```
Size: 1.5rem (24px)
Weight: 700 (Bold)
Line-height: 1.4
Letter-spacing: 0
Usage: Feature titles, callouts
```

#### Body Text (Large)
```
Size: 1.125rem (18px)
Weight: 400 (Regular)
Line-height: 1.6
Letter-spacing: 0.01em
Usage: Descriptions, long-form content
```

#### Body Text (Regular)
```
Size: 1rem (16px)
Weight: 400 (Regular)
Line-height: 1.6
Letter-spacing: 0
Usage: Default body text, paragraphs
```

#### Body Text (Small)
```
Size: 0.875rem (14px)
Weight: 500 (Medium)
Line-height: 1.5
Letter-spacing: 0.005em
Usage: Labels, helper text, captions
```

## Component Styling

### Buttons

#### Primary Button
```css
background: linear-gradient(to right, #7c3aed, #e91e63);
color: white;
padding: 1rem 2rem (16px 32px);
border-radius: 0.75rem (12px);
font-weight: 700;
transition: all 300ms ease;
box-shadow: 0 10px 25px rgba(233, 30, 99, 0.25);
```

**Hover State**:
```css
box-shadow: 0 15px 35px rgba(233, 30, 99, 0.4);
transform: translateY(-2px);
```

**Active State**:
```css
transform: scale(0.95);
```

#### Secondary Button
```css
border: 2px solid rgba(124, 58, 237, 0.5);
background: transparent;
color: white;
padding: 0.875rem 1.75rem (14px 28px);
border-radius: 0.75rem (12px);
font-weight: 700;
transition: all 300ms ease;
```

**Hover State**:
```css
background: rgba(124, 58, 237, 0.1);
border-color: rgba(124, 58, 237, 1);
```

### Cards

#### Glass Card
```css
background: rgba(15, 23, 42, 0.6);
backdrop-filter: blur(1.5rem);
border: 1px solid rgba(124, 58, 237, 0.2);
border-radius: 1.5rem;
padding: 2rem;
```

#### Glass Card Hover
```css
background: rgba(15, 23, 42, 0.8);
border-color: rgba(233, 30, 99, 0.5);
box-shadow: 0 20px 40px rgba(233, 30, 99, 0.2);
transform: translateY(-8px);
```

### Input Fields

#### Standard Input
```css
background: rgba(30, 41, 59, 0.5);
border: 1px solid rgba(124, 58, 237, 0.3);
border-radius: 0.5rem;
padding: 0.75rem 1rem;
color: white;
font-size: 1rem;
transition: all 300ms ease;
```

**Focus State**:
```css
border-color: rgba(233, 30, 99, 0.5);
box-shadow: 0 0 0 3px rgba(233, 30, 99, 0.1);
background: rgba(30, 41, 59, 0.8);
```

## Spacing System

```
2xs: 4px
xs:  8px
sm:  12px
md:  16px
lg:  24px
xl:  32px
2xl: 48px
3xl: 64px
4xl: 80px
```

**Usage Pattern**:
- **Padding**: Use lg-xl for cards, md for buttons
- **Margin**: Use lg-2xl between sections
- **Gap**: Use md-lg for component spacing
- **Border Radius**: 8px for buttons, 12px for cards, 16px for large elements

## Border & Shadow System

### Borders

#### Subtle Border
```css
border: 1px solid rgba(124, 58, 237, 0.2);
```

#### Medium Border
```css
border: 1px solid rgba(124, 58, 237, 0.5);
```

#### Accent Border
```css
border: 2px solid rgba(233, 30, 99, 0.5);
```

### Shadows

#### Small Shadow
```css
box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
```

#### Medium Shadow
```css
box-shadow: 0 10px 25px rgba(233, 30, 99, 0.15);
```

#### Large Shadow
```css
box-shadow: 0 20px 40px rgba(233, 30, 99, 0.2);
```

#### Glow Shadow
```css
box-shadow: 0 0 30px rgba(124, 58, 237, 0.3);
```

## Animation Specifications

### Entrance Animations

#### Fade In
```css
animation: fadeIn 600ms ease-out forwards;
keyframes: {
  0% { opacity: 0; }
  100% { opacity: 1; }
}
```

#### Slide Up
```css
animation: slideUp 600ms ease-out forwards;
keyframes: {
  0% { opacity: 0; transform: translateY(30px); }
  100% { opacity: 1; transform: translateY(0); }
}
```

#### Staggered Children
```css
:nth-child(1) { animation-delay: 0.1s; }
:nth-child(2) { animation-delay: 0.2s; }
:nth-child(3) { animation-delay: 0.3s; }
```

### Interactive Animations

#### Hover Scale
```css
transition: transform 300ms ease;
:hover { transform: scale(1.05); }
```

#### Glow Pulse
```css
animation: glowPulse 2s ease-in-out infinite;
keyframes: {
  0%, 100% { box-shadow: 0 0 20px rgba(233, 30, 99, 0.4); }
  50% { box-shadow: 0 0 40px rgba(233, 30, 99, 0.6); }
}
```

## Icon System

### Icon Sizing

- **Small**: 12px-16px (labels, badges)
- **Medium**: 20px-24px (nav, cards)
- **Large**: 32px-48px (hero, features)
- **Extra Large**: 64px+ (section headers)

### Icon Colors

- **Primary**: `#7c3aed` (purple)
- **Accent**: `#e91e63` (magenta)
- **Neutral**: `#9ca3af` (gray)
- **On Dark**: `#ffffff` (white)

## Responsive Design Tokens

### Breakpoints
```
xs: 320px
sm: 640px
md: 768px
lg: 1024px
xl: 1280px
2xl: 1536px
```

### Viewport Considerations

#### Mobile (< 640px)
- Font sizes: -1 level (reduce h1 to 2.25rem)
- Padding: sm-md (12-16px)
- Gap: sm (12px)
- Full-width buttons

#### Tablet (640px - 1024px)
- Font sizes: Standard scale
- Padding: md-lg (16-24px)
- Gap: md (16px)
- 2-column layouts

#### Desktop (> 1024px)
- Font sizes: Full scale
- Padding: lg-xl (24-32px)
- Gap: lg (24px)
- 3-4 column layouts

## Accessibility Standards

### Color Contrast Ratios

**Minimum Standards (WCAG AA)**:
- Large text (18pt+): 3:1
- Normal text: 4.5:1
- UI components: 3:1

**Target Standards (WCAG AAA)**:
- Large text (18pt+): 4.5:1
- Normal text: 7:1

### Current Implementation

- White on Dark Navy: 21:1 (AAA)
- Purple on White: 7.2:1 (AAA)
- Magenta on White: 6.8:1 (AAA)
- Gray on Dark Navy: 5.5:1 (AA)

## Usage Examples

### Hero Section
```
Background: Dark Navy (#0f172a)
Text: White (#ffffff)
Accents: Purple gradient + Magenta highlights
Overlays: Pulsing background orbs with opacity
Animation: Fade-in on scroll with stagger
```

### CTA Buttons
```
Background: Primary-to-Accent gradient
Text: White (#ffffff)
Shadow: Magenta glow effect
Hover: Increased shadow, scale up 5%
Active: Scale down to 95%
```

### Cards
```
Background: Glass effect with backdrop blur
Border: Subtle purple border
Shadow: Medium shadow on hover
Hover: Scale 5%, border to magenta
Transition: 300ms ease for all properties
```

### Form Inputs
```
Background: Semi-transparent slate
Border: Purple with opacity
Text: White
Placeholder: Gray
Focus: Purple border, glow shadow
```

## Animation Timeline

### Page Load
1. Header fades in (0s)
2. Hero title fades in (0.1s delay)
3. Hero subtitle fades in (0.2s delay)
4. CTA buttons fade in (0.3s delay)
5. Stats counter animates (on scroll)

### Scroll Interactions
- Section backgrounds: None (static)
- Text content: Fade in + slide up (600ms)
- Cards: Individual stagger (100-150ms)
- Counters: Animate when visible

## Brand Voice in Design

- **Modern**: Clean lines, contemporary colors, smooth animations
- **Energetic**: Vibrant purple-magenta, dynamic gradients
- **Professional**: Balanced whitespace, readable typography
- **Accessible**: High contrast, clear hierarchy, intuitive layout
- **Responsive**: Works seamlessly across all devices

## Dark Mode Considerations

Current implementation is dark mode only. For future light mode:
- Invert backgrounds (white/light gray)
- Darken text colors
- Reduce opacity on overlays
- Adjust shadow colors
- Maintain color contrast ratios

---

**Design System Version**: 1.0.0  
**Last Updated**: 2026-04-14  
**Color Palette**: Purple/Magenta/Cyan on Dark Navy
